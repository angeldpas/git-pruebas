<?php
/**
 * The template for displaying all single posts.
 *
 * @package Fresh
 */

get_header(); ?>

	<div id="wrapper" class="<?php fresh_single_page_class(); ?>">

		<div class="container clearfix">

			<?php
			fresh_single_featured_image_effect();

			fresh_action( 'before_content' );

			fresh_single_sections();

			fresh_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === fresh_get_settings( 'related_posts_position' ) ) {
			fresh_related_posts();
		}
		?>

<?php
get_footer();
