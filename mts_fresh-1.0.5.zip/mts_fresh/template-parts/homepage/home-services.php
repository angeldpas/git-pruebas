<?php
/**
 * Homepage Section - Services
 *
 * @package Fresh
 */

$services = fresh_get_settings( 'home_services' );

if ( empty( $services ) && ! is_array( $services ) ) {
	return;
}
?>

<section class="services-section clearfix">

	<div class="container clearfix">

		<?php
		$i = 0;
		echo '<ul>';

		foreach ( $services as $service ) {
			printf(
				'<li class="service-item item-' . ++$i . '"><img src="%1$s" alt="%2$s"><h2>%2$s</h2><a class="button border" href="%3$s">%4$s</a></li>',
				$service['services_image'],
				$service['services_title'],
				$service['services_button_url'],
				$service['services_button_text']
			);
		}

		echo '</ul>';
		?>

	</div><!-- .container -->

</section>
