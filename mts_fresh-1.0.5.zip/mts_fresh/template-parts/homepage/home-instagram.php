<?php
/**
 * Homepage Section - Instagram
 *
 * @package Fresh
 */

$title = fresh_get_settings( 'instagram_title' );
$text  = fresh_get_settings( 'instagram_text' );

$instagram_username = fresh_get_settings( 'instagram_username' );
$instagram_num_post = fresh_get_settings( 'instagram_num_post' );

$button_text = fresh_get_settings( 'instagram_button_text' );
$button_url  = fresh_get_settings( 'instagram_button_url' );

if ( ! $title && ! $text && ! $instagram_username && ! $instagram_num_post && ! $button_text && ! $button_url ) {
	return;
}
?>

<section class="instagram-section clearfix">

	<div class="container">

		<?php
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}
		if ( $instagram_username && $instagram_num_post ) {
			echo '<div class="instagram-feeds">';
				fresh_instagram( $instagram_username, $instagram_num_post );
			echo '</div>';
		}
		if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
			printf( '<a class="button" href="%1$s">%2$s</a>', $button_url, $button_text );
		}
		?>

	</div><!-- .container -->

</section>
