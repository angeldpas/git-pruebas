<?php
/**
 * Homepage Section - Testimonials
 *
 * @package Fresh
 */

$title        = fresh_get_settings( 'testimonials_section_title' );
$testimonials = fresh_get_settings( 'home_testimonials' );

if ( empty( $testimonials ) && ! is_array( $testimonials ) ) {
	return;
}
?>

<section class="testimonials-section clearfix">

	<div class="container">

		<?php
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		?>

		<div class="testimonials-container clearfix loading">

			<div class="testimonial-items clearfix loading">

				<?php
				// $i = 0;
				foreach ( $testimonials as $testimonial ) {
					echo '<div class="testimonial-item">';
					printf(
						'<div class="author-img"><img src="%1$s" alt="%2$s"></div><div class="testimonials-text"><div class="author-name">%2$s</div><p>%3$s</p></div>',
						$testimonial['testimonials_author_image'],
						$testimonial['testimonials_author_name'],
						$testimonial['testimonials_text']
					);
					echo '</div>';
				}

				?>

			</div>

		</div><!-- .testimonials-container -->

	</div><!-- .container -->

</section>
