<?php
/**
 * Homepage Section - Slider
 *
 * @package Fresh
 */

$slider = fresh_get_settings( 'home_slider' );

if ( empty( $slider ) && ! is_array( $slider ) ) {
	return;
}
?>

<section class="slider-section clearfix">

	<div class="primary-slider-container clearfix loading">

		<div id="slider" class="primary-slider">

			<?php
			$i = 0;
			foreach ( $slider as $slide ) {
				echo '<div class="primary-slider-item slider-item item-' . ++$i . '">';
				printf(
					'<div class="container clearfix"><div class="slider-caption"><p class="slider-text">%1$s</p><h2>%2$s</h2><h3>%3$s</h3><a class="button" href="%4$s">%5$s</a></div></div>',
					$slide['slider_text'],
					$slide['slider_big_title'],
					$slide['slider_title'],
					$slide['slider_button_url'],
					$slide['slider_button_text']
				);
				echo '</div>';
			}

			?>

		</div><!-- .primary-slider -->

	</div><!-- .slider-container -->

</section>
