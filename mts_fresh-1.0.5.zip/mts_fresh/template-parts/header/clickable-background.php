<?php
/**
 * Clickable Background
 *
 */

if ( fresh_get_settings( 'background_clickable' ) && fresh_get_settings( 'background_link' ) ) {
	$target = ( 1 === fresh_get_settings( 'background_link_new_tab' ) ) ? 'target="_blank"' : '';
	printf( '<a href="%1$s" rel="nofollow" class="clickable-background" %2$s>', fresh_get_settings( 'background_link' ), $target );
}
