<?php
/**
 * Header adcode
 *
 */

$ad_show_on = fresh_get_settings( 'header_adcode_show' );
$layouts    = fresh_get_settings( 'header_styles' );

if ( ! empty( fresh_get_settings( 'mts_header_adcode' ) ) ) {
	echo ( 'header-default' !== $layouts ) ? '<div class="container small-header">' : '';

	if ( 'all' === $ad_show_on ) {
		if ( ! empty( fresh_get_settings( 'mts_header_adcode' ) ) ) {
			if ( 0 !== fresh_get_settings( 'header_ad_size' ) ) {
				$style = 'max-width: 100%;';
			}
			?>
			<div class="widget-header">
				<div style="<?php ad_size_value( fresh_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
					<?php echo fresh_get_settings( 'mts_header_adcode' ); ?>
				</div>
			</div>
		<?php
		}
	}
	if ( 'home' === $ad_show_on ) {
		if ( is_home() || is_front_page() ) {
			if ( ! empty( fresh_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== fresh_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( fresh_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo fresh_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'single' === $ad_show_on ) {
		if ( is_single() ) {
			if ( ! empty( fresh_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== fresh_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( fresh_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo fresh_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'page' === $ad_show_on ) {
		if ( is_page() ) {
			if ( ! empty( fresh_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== fresh_get_settings( 'header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( fresh_get_settings( 'header_ad_size' ) ); ?> <?php echo isset( $style ) ? $style : ''; ?>">
						<?php echo fresh_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}

	echo ( 'header-default' !== $layouts ) ? '</div>' : '';
}
