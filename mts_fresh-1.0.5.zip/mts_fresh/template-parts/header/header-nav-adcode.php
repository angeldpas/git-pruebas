<?php if ( fresh_get_settings( 'navigation_ad' ) && fresh_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( fresh_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo fresh_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
