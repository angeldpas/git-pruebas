<?php
/**
 * HomePage CTA Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-cta'] = array(
	'title' => esc_html__( 'Call to Action', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the call to action section.', 'fresh' ),
);

$sections['homepage-cta'] = array(

	array(
		'id'       => 'cta_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Call to Action Section Background', 'fresh' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'fresh' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'cta_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter title for call to action section.', 'fresh' ),
		'std'      => 'Don\'t forget: Free Standard Shipping on orders $99+!',
	),
	array(
		'id'    => 'cta_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'font-weight'   => '600',
			'font-size'     => '30px',
			'line-height'   => '1',
			'color'         => '#444444',
			'css-selectors' => '.cta-section h2',
		),
	),

	array(
		'id'       => 'cta_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'fresh' ),
		'std'      => 'Read Shipping Info',
	),
	array(
		'id'       => 'cta_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'fresh' ),
		'std'      => '#',
	),
	array(
		'id'       => 'cta_button_text_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Text Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button text color.', 'lawyer' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'cta_button_bg_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Background Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button background color.', 'lawyer' ),
		'std'      => fresh_get_settings( 'primary_color_scheme' ),
	),

	array(
		'id'       => 'cta_left_bg_image',
		'type'     => 'upload',
		'title'    => esc_html__( 'Uplaod Left Background Image', 'fresh' ),
		'sub_desc' => esc_html__( 'Recommended size: 362 x 317 in px.', 'fresh' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/vegi-small.png',
	),
	array(
		'id'       => 'cta_left_bg_position',
		'type'     => 'margin',
		'title'    => esc_html__( 'Left Backround Image Position', 'fresh' ),
		'sub_desc' => esc_html__( 'Set left background position from here.', 'fresh' ),
		'right'    => false,
		'bottom'   => false,
		'std'      => array(
			'top'  => '18px',
			'left' => '-20px',
		),
	),

	array(
		'id'       => 'cta_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set call to action section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '86px',
			'right'  => '0',
			'bottom' => '54px',
			'left'   => '0',
		),
	),

);
