<?php
/**
 * Header Tab
 *
 * @package Fresh
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'fresh' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'fresh' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'header_styles',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'fresh' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'fresh' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
			'header-layout3' => array( 'img' => $uri . 'headers/header-layout3.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'         => 'top_bar_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Top Bar', 'fresh' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'top_bar_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Text', 'fresh' ),
		'std'        => 'Eat Local Organic Food!',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'header_social_icons',
		'title'      => esc_html__( 'Header Social Icons', 'fresh' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'fresh' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'fresh' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'    => 'header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'fresh' ),
			),
			array(
				'id'       => 'header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'fresh' ),
				'sub_desc' => esc_html__( 'Select border.', 'fresh' ),
			),
			array(
				'id'    => 'header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'fresh' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'twitter'   => array(
				'group_title'               => 'Twitter',
				'group_sort'                => '2',
				'header_icon_title'         => 'Twitter',
				'header_icon'               => 'twitter',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#444444',
				'header_icon_hover_color'   => fresh_get_settings( 'primary_color_scheme' ),
				'header_icon_margin'        => array(
					'top'    => '4px',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '17px',
				),
				'header_icon_border_radius' => '0',
			),
			'youtube'   => array(
				'group_title'               => 'Youtube',
				'group_sort'                => '1',
				'header_icon_title'         => 'Youtube',
				'header_icon'               => 'youtube-play',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#444444',
				'header_icon_hover_color'   => fresh_get_settings( 'primary_color_scheme' ),
				'header_icon_margin'        => array(
					'top'    => '4px',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '16px',
				),
				'header_icon_border_radius' => '0',
			),
			'instagram' => array(
				'group_title'               => 'Instagram',
				'group_sort'                => '1',
				'header_icon_title'         => 'Instagram',
				'header_icon'               => 'instagram',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#444444',
				'header_icon_hover_color'   => fresh_get_settings( 'primary_color_scheme' ),
				'header_icon_margin'        => array(
					'top'    => '4px',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '15px',
				),
				'header_icon_border_radius' => '0',
			),
			'facebook'  => array(
				'group_title'               => 'Facebook',
				'group_sort'                => '1',
				'header_icon_title'         => 'Facebook',
				'header_icon'               => 'facebook-official',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#444444',
				'header_icon_hover_color'   => fresh_get_settings( 'primary_color_scheme' ),
				'header_icon_margin'        => array(
					'top'    => '4px',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '17px',
				),
				'header_icon_border_radius' => '0',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'top_bar_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Bar Margin', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set top bar margin from here.', 'fresh' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '0',
			'bottom' => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'top_bar_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Bar Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set top bar padding from here.', 'fresh' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '8px',
			'bottom' => '7px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Header Background', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'fresh' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#f8faf4',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'    => 'header_nav_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Header Settings', 'fresh' ),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'fresh' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'fresh' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Button', 'fresh' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Nav Button</strong> completely.', 'fresh' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Button Text', 'fresh' ),
		'sub_desc'   => esc_html__( 'Enter button text.', 'fresh' ),
		'std'        => 'Recipes',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'nav_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button_url',
		'type'       => 'text',
		'title'      => esc_html__( 'Button URL', 'fresh' ),
		'sub_desc'   => esc_html__( 'Enter button URL.', 'fresh' ),
		'std'        => '#',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'nav_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'       => 'header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'fresh' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'fresh' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'fresh' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '19px',
			'bottom' => '19px',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border.', 'fresh' ),
	),

	array(
		'id'       => 'header_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Main Navigation Background', 'fresh' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'fresh' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'    => 'header_general_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Header General Settings', 'fresh' ),
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'fresh' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'fresh' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'fresh' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'fresh' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'fresh' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'fresh' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'fresh' ),
		'std'      => '#ffffff',
	),

);
