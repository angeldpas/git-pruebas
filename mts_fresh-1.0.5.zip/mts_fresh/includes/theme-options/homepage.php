<?php
/**
 * HomePage Tab
 *
 * @package Fresh
 */

$menus['homepage'] = array(
	'icon'  => 'fa-home',
	'title' => esc_html__( 'Homepage', 'fresh' ),
);

$menus['homepage']['child']['homepage-sections'] = array(
	'title' => esc_html__( 'Homepage Sections', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Homepage Sections.', 'fresh' ),
);

$sections['homepage-sections'] = array(

	array(
		'id'       => 'homepage_layout',
		'type'     => 'layout',
		'title'    => esc_html__( 'Homepage Section Manager', 'fresh' ),
		'sub_desc' => esc_html__( 'Organize how you want the sections to appear on the homepage', 'fresh' ),
		'options'  => array(
			'enabled'  => array(
				'slider'       => esc_html__( 'Slider', 'fresh' ),
				'services'     => esc_html__( 'Services', 'fresh' ),
				'featured'     => esc_html__( 'Featured', 'fresh' ),
				'services2'    => esc_html__( 'Services 2', 'fresh' ),
				'testimonials' => esc_html__( 'Testimonials', 'fresh' ),
				'instagram'    => esc_html__( 'Instagram', 'fresh' ),
				'cta'          => esc_html__( 'Click to Action', 'fresh' ),
			),
			'disabled' => array(),
		),
		'std'      => array(
			'enabled'  => array(
				'slider'       => esc_html__( 'Slider', 'fresh' ),
				'services'     => esc_html__( 'Services', 'fresh' ),
				'featured'     => esc_html__( 'Featured', 'fresh' ),
				'services2'    => esc_html__( 'Services 2', 'fresh' ),
				'testimonials' => esc_html__( 'Testimonials', 'fresh' ),
				'instagram'    => esc_html__( 'Instagram', 'fresh' ),
				'cta'          => esc_html__( 'Click to Action', 'fresh' ),
			),
			'disabled' => array(),
		),
	),
);
