<?php
/**
 * HomePage Featured Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-featured'] = array(
	'title' => esc_html__( 'Featured', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the featured section.', 'fresh' ),
);

$sections['homepage-featured'] = array(

	array(
		'id'       => 'featured_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Featured Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured-bg.png',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'right top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'featured_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter title for featured section.', 'lawyer' ),
		'std'      => '100%',
	),
	array(
		'id'       => 'featured_small_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Small Title', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter small title for featured section.', 'lawyer' ),
		'std'      => 'Organic',
	),
	array(
		'id'       => 'featured_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Text', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter text for featured section.', 'lawyer' ),
		'std'      => 'Your favorite Products from the Field',
	),

	array(
		'id'       => 'featured_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Want More?',
	),

	array(
		'id'       => 'featured_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),
	array(
		'id'       => 'featured_button_text_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Text Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button text color.', 'lawyer' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'featured_button_bg_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Background Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button background color.', 'lawyer' ),
		'std'      => '#ec7012',
	),

	array(
		'id'       => 'featured_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set featured section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '156px',
			'right'  => '0',
			'bottom' => '170px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'featured_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Caveat Brush',
			'color'         => '#ffffff',
			'font-weight'   => '400',
			'font-size'     => '136px',
			'line-height'   => '1',
			'css-selectors' => '.featured-section h2',
		),
	),
	array(
		'id'    => 'featured_small_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Small Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Small Title',
			'preview-color' => 'dark',
			'font-family'   => 'Caveat Brush',
			'color'         => '#ffffff',
			'font-weight'   => '400',
			'font-size'     => '111px',
			'line-height'   => '1',
			'css-selectors' => '.featured-section h3',
		),
	),
	array(
		'id'    => 'featured_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'dark',
			'font-family'   => 'Open Sans',
			'color'         => '#ffffff',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'css-selectors' => '.featured-section p',
		),
	),

);
