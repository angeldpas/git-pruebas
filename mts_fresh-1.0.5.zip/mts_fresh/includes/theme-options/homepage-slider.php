<?php
/**
 * HomePage Slider Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-slider'] = array(
	'title' => esc_html__( 'Slider', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the slider section.', 'fresh' ),
);

$sections['homepage-slider'] = array(

	array(
		'id'        => 'home_slider',
		'type'      => 'group',
		'title'     => esc_html__( 'Slider', 'fresh' ),
		'sub_desc'  => esc_html__( 'Add slider appearing on the homepage.', 'fresh' ),
		'groupname' => esc_html__( 'Slider', 'fresh' ),
		'subfields' => array(
			array(
				'id'    => 'slider_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'fresh' ),
			),
			array(
				'id'    => 'slider_text_color',
				'type'  => 'color',
				'title' => esc_html__( 'Text Color', 'fresh' ),
			),
			array(
				'id'    => 'slider_big_title',
				'type'  => 'text',
				'title' => esc_html__( 'Big Title', 'fresh' ),
			),
			array(
				'id'    => 'slider_big_title_color',
				'type'  => 'color',
				'title' => esc_html__( 'Big Title Color', 'fresh' ),
			),
			array(
				'id'    => 'slider_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'    => 'slider_title_color',
				'type'  => 'color',
				'title' => esc_html__( 'Title Color', 'fresh' ),
			),
			array(
				'id'    => 'slider_button_text',
				'type'  => 'text',
				'title' => esc_html__( 'Button Text', 'fresh' ),
			),
			array(
				'id'    => 'slider_button_url',
				'type'  => 'text',
				'title' => esc_html__( 'Button URL', 'fresh' ),
			),
			array(
				'id'    => 'slider_button_text_color',
				'type'  => 'color',
				'title' => esc_html__( 'Button Text Color', 'fresh' ),
			),
			array(
				'id'    => 'slider_button_bg_color',
				'type'  => 'color',
				'title' => esc_html__( 'Button Background Color', 'fresh' ),
			),
			array(
				'id'       => 'slider_alignment',
				'type'     => 'select',
				'title'    => esc_html__( 'Text Alignment', 'fresh' ),
				'sub_desc' => esc_html__( 'Choose position of text.', 'fresh' ),
				'options'  => array(
					'left'  => esc_html__( 'Left', 'fresh' ),
					'right' => esc_html__( 'Right', 'fresh' ),
				),
			),
			array(
				'id'     => 'slider_background',
				'type'   => 'upload',
				'title'  => esc_html__( 'Uplaod Slider\'s Background Image', 'fresh' ),
				'return' => 'url',
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'               => '1',
				'slider_text'              => 'Your Favourite',
				'slider_text_color'        => '#444444',
				'slider_big_title'         => 'Fresh',
				'slider_big_title_color'   => '#ffffff',
				'slider_title'             => 'Vegetables',
				'slider_title_color'       => '#ffffff',
				'slider_button_text'       => 'Shop Now',
				'slider_button_url'        => '#',
				'slider_button_text_color' => '#ffffff',
				'slider_button_bg_color'   => '#ec7012',
				'slider_alignment'         => 'left',
				'slider_background'        => get_template_directory_uri() . '/images/slider-1-bg.png',
			),
			'2' => array(
				'group_sort'               => '2',
				'slider_text'              => 'Your Favourite',
				'slider_text_color'        => '#444444',
				'slider_big_title'         => 'Fresh',
				'slider_big_title_color'   => '#ffffff',
				'slider_title'             => 'Vegetables',
				'slider_title_color'       => '#ffffff',
				'slider_button_text'       => 'Shop Now',
				'slider_button_url'        => '#',
				'slider_button_text_color' => '#ffffff',
				'slider_button_bg_color'   => '#ec7012',
				'slider_alignment'         => 'right',
				'slider_background'        => get_template_directory_uri() . '/images/slider-2-bg.png',
			),
		),
	),

	array(
		'id'       => 'slider_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set slider section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '153px',
			'right'  => '0',
			'bottom' => '188px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'slider_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'fresh' ),
		'color' => false,
		'std'   => array(
			'preview-text'   => 'Text',
			'preview-color'  => 'light',
			'font-family'    => 'Open Sans',
			'font-weight'    => '600',
			'font-size'      => '30px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.slider-section p',
		),
	),
	array(
		'id'    => 'slider_big_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Big Title Font', 'fresh' ),
		'color' => false,
		'std'   => array(
			'preview-text'  => 'Big Title',
			'preview-color' => 'light',
			'font-family'   => 'Caveat Brush',
			'font-weight'   => '400',
			'font-size'     => '150px',
			'line-height'   => '1',
			'css-selectors' => '.slider-section h2',
		),
	),
	array(
		'id'    => 'slider_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'color' => false,
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Caveat Brush',
			'font-weight'   => '400',
			'font-size'     => '91px',
			'line-height'   => '1',
			'css-selectors' => '.slider-section h3',
		),
	),

);
