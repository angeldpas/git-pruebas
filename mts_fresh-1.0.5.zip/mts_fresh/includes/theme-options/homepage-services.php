<?php
/**
 * HomePage Services Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-services'] = array(
	'title' => esc_html__( 'Services', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the services section.', 'fresh' ),
);

$sections['homepage-services'] = array(

	array(
		'id'        => 'home_services',
		'type'      => 'group',
		'title'     => esc_html__( 'Services', 'fresh' ),
		'sub_desc'  => esc_html__( 'Add services appearing on the homepage.', 'fresh' ),
		'groupname' => esc_html__( 'Service', 'fresh' ),
		'subfields' => array(
			array(
				'id'    => 'services_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'       => 'services_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Uplaod Service Image', 'fresh' ),
				'sub_desc' => esc_html__( 'Recommended size: 215 x 215 in px.', 'fresh' ),
				'return'   => 'url',
			),
			array(
				'id'    => 'services_button_text',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'    => 'services_button_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'       => 'services_bg_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Uplaod Service Background Image', 'fresh' ),
				'sub_desc' => esc_html__( 'Recommended size: 350 x 485 in px.', 'fresh' ),
				'return'   => 'url',
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'           => '1',
				'services_title'       => 'Breakfast',
				'services_image'       => get_template_directory_uri() . '/images/service-1.png',
				'services_button_text' => 'Click Here',
				'services_button_url'  => '#',
				'services_bg_image'    => get_template_directory_uri() . '/images/service-1-bg.png',
			),
			'2' => array(
				'group_sort'           => '2',
				'services_title'       => 'Dessert Recipes',
				'services_image'       => get_template_directory_uri() . '/images/service-2.png',
				'services_button_text' => 'Click Here',
				'services_button_url'  => '#',
				'services_bg_image'    => get_template_directory_uri() . '/images/service-2-bg.png',
			),
			'3' => array(
				'group_sort'           => '3',
				'services_title'       => 'Dinner Recipes',
				'services_image'       => get_template_directory_uri() . '/images/service-3.png',
				'services_button_text' => 'Click Here',
				'services_button_url'  => '#',
				'services_bg_image'    => get_template_directory_uri() . '/images/service-3-bg.png',
			),
		),
	),

	array(
		'id'       => 'services_image_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border', 'fresh' ),
		'std'      => array(
			'direction' => 'all',
			'color'     => '#ffffff',
			'size'      => '6',
			'style'     => 'solid',
		),
	),

	array(
		'id'       => 'services_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set services section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '103px',
			'right'  => '0',
			'bottom' => '86px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'services_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Open Sans',
			'font-weight'   => '700',
			'color'         => '#ffffff',
			'font-size'     => '28px',
			'line-height'   => '1',
			'css-selectors' => '.services-section h2',
		),
	),

);
