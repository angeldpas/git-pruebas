<?php
/**
 * Single Tab
 *
 * @package Fresh
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'fresh' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'show_single_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'fresh' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'fresh' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'fresh' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'fresh' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'fresh' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'fresh' ),
					'subfields' => array(
						array(
							'id'    => 'tags_bgcolor',
							'type'  => 'color',
							'title' => esc_html__( 'Tags background color', 'fresh' ),
							'std'   => '#ffd05a',
						),
					),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'fresh' ),
					'subfields' => array(),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'fresh' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'fresh' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'fresh' ),
							'std'      => 'Related Recipes',
						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'fresh' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'fresh' ),
								'categories' => esc_html__( 'Categories', 'fresh' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'fresh' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'fresh' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'fresh' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'fresh' ),
		'options'  => array(
			'enabled'  => array(
				'author'   => array(
					'label'     => esc_html__( 'Author Name', 'fresh' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'fresh' ),
						),
					),
				),
				'date'     => array(
					'label'     => esc_html__( 'Date', 'fresh' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'fresh' ),
						),
					),
				),
				'category' => array(
					'label'     => esc_html__( 'Categories', 'fresh' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'fresh' ),
						),
					),
				),
			),
			'disabled' => array(
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'fresh' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'fresh' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'fresh' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'fresh' ),
		'std'      => '1',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select divider icon from here.', 'fresh' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'fresh' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#949592',
			'css-selectors' => '.breadcrumb a, .rank-math-breadcrumb a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'fresh' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'fresh' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'fresh' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'fresh' ),
		'std'      => '1',
	),
);
