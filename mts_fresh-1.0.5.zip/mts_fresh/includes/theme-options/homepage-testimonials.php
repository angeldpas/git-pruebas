<?php
/**
 * HomePage Testimonials Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-testimonials'] = array(
	'title' => esc_html__( 'Testimonials', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the testimonials section.', 'fresh' ),
);

$textimonial_text = '“We’ve been Lettuce customers for a few years now! The veggies, fruit, cheese, bread, eggs, and mushrooms I receive are insanely delicious and very affordable. Keep doing what you’re doing!”';

$sections['homepage-testimonials'] = array(

	array(
		'id'       => 'testimonials_section_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'fresh' ),
		'sub_desc' => esc_html__( 'Set testimonials section title from here.', 'fresh' ),
		'std'      => 'People About Us',
	),

	array(
		'id'    => 'testimonials_section_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Section Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Section Title',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'color'         => color_luminance( fresh_get_settings( 'primary_color_scheme' ), -0.2 ),
			'font-weight'   => '700',
			'font-size'     => '40px',
			'line-height'   => '1',
			'css-selectors' => '.testimonials-section h2',
		),
	),

	array(
		'id'        => 'home_testimonials',
		'type'      => 'group',
		'title'     => esc_html__( 'Testimonials', 'fresh' ),
		'sub_desc'  => esc_html__( 'Add testimonials appearing on the homepage.', 'fresh' ),
		'groupname' => esc_html__( 'Testimonial', 'fresh' ),
		'subfields' => array(
			array(
				'id'    => 'testimonials_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'       => 'testimonials_author_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Uplaod Author Image', 'fresh' ),
				'sub_desc' => esc_html__( 'Recommended size: 90 x 90 in px.', 'fresh' ),
				'return'   => 'url',
			),
			array(
				'id'    => 'testimonials_author_name',
				'type'  => 'text',
				'title' => esc_html__( 'Author Name', 'fresh' ),
			),
			array(
				'id'    => 'testimonials_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Testimonial', 'fresh' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                => '1',
				'testimonials_title'        => 'Testimonial 1',
				'testimonials_author_image' => get_template_directory_uri() . '/images/author-1.png',
				'testimonials_author_name'  => 'Helen Herbert',
				'testimonials_text'         => $textimonial_text,
			),
			'2' => array(
				'group_sort'                => '2',
				'testimonials_title'        => 'Testimonial 2',
				'testimonials_author_image' => get_template_directory_uri() . '/images/author-2.png',
				'testimonials_author_name'  => 'Albert',
				'testimonials_text'         => $textimonial_text,
			),
			'3' => array(
				'group_sort'                => '3',
				'testimonials_title'        => 'Testimonial 3',
				'testimonials_author_image' => get_template_directory_uri() . '/images/author-1.png',
				'testimonials_author_name'  => 'Helen Herbert',
				'testimonials_text'         => $textimonial_text,
			),
			'4' => array(
				'group_sort'                => '4',
				'testimonials_title'        => 'Testimonial 4',
				'testimonials_author_image' => get_template_directory_uri() . '/images/author-2.png',
				'testimonials_author_name'  => 'Albert',
				'testimonials_text'         => $textimonial_text,
			),
		),
	),

	array(
		'id'       => 'testimonials_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set testimonials section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '77px',
			'right'  => '0',
			'bottom' => '113px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'testimonials_author_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Name Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Author Name',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'color'         => '#15181f',
			'font-weight'   => '600',
			'font-size'     => '14px',
			'line-height'   => '1',
			'css-selectors' => '.testimonials-section .author-name',
		),
	),
	array(
		'id'    => 'testimonials_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'color'         => '#444444',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'line-height'   => '32px',
			'css-selectors' => '.testimonials-section p',
		),
	),

	array(
		'id'    => 'testimonials_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Testimonials Backgrounds', 'fresh' ),
	),

	array(
		'id'       => 'testimonials_left_bg_image',
		'type'     => 'upload',
		'title'    => esc_html__( 'Uplaod Left Background Image', 'fresh' ),
		'sub_desc' => esc_html__( 'Recommended size: 393 x 344 in px.', 'fresh' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/vegi-1.png',
	),
	array(
		'id'       => 'testimonials_left_bg_position',
		'type'     => 'margin',
		'title'    => esc_html__( 'Left Backround Image Position', 'fresh' ),
		'sub_desc' => esc_html__( 'Set left background position from here.', 'fresh' ),
		'right'    => false,
		'bottom'   => false,
		'std'      => array(
			'top'  => '-144px',
			'left' => '-174px',
		),
	),

	array(
		'id'       => 'testimonials_right_bg_image',
		'type'     => 'upload',
		'title'    => esc_html__( 'Uplaod Right Background Image', 'fresh' ),
		'sub_desc' => esc_html__( 'Recommended size: 205 x 230 in px.', 'fresh' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/vegi-2.png',
	),
	array(
		'id'       => 'testimonials_right_bg_position',
		'type'     => 'margin',
		'title'    => esc_html__( 'Right Backround Image Position', 'fresh' ),
		'sub_desc' => esc_html__( 'Set right background position from here.', 'fresh' ),
		'top'      => false,
		'left'     => false,
		'std'      => array(
			'right'  => '0',
			'bottom' => '-61px',
		),
	),

);
