<?php
/**
 * Set fresh layout according to options
 *
 * @package Fresh
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Fresh_Layout extends Fresh_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'fresh_before_wrapper', 'add_header' );
		// $this->add_action( 'fresh_before_content', 'single_heading_secton' );
		$this->add_action( 'fresh_single_post_header', 'single_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash   = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
			'header-layout3' => 'layout3',
		);
		$layout = fresh_get_settings( 'header_styles' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header layout
	 */
	public function single_post_header() {
		?>
		<header class="single-full-header clearfix">

			<?php
			if ( fresh_get_settings( 'show_single_featured' ) ) {
				the_post_thumbnail( 'fresh-single-featured', array( 'class' => 'single-featured-image' ) );
			}
			?>
			<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
			<?php fresh_the_post_meta( 'single' ); ?>

		</header><!--.headline_area-->
		<?php
	}
}

// Init.
new Fresh_Layout;
